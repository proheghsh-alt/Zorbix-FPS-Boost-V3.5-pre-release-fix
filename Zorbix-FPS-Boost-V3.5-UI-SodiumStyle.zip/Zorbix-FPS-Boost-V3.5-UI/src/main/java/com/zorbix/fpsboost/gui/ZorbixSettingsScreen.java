package com.zorbix.fpsboost.gui;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ZorbixSettingsScreen extends Screen {
    private final Screen parent;
    private int page = 0;

    private static final String[] CATEGORIES = {
            "Performance",
            "Graphics",
            "Animations",
            "Camera & FOV",
            "Environment",
            "HUD",
            "Profiles"
    };

    public ZorbixSettingsScreen(Screen parent) {
        super(Text.literal("Zorbix Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = Math.max(10, this.width / 2 - 150);
        int top = 45;

        for (int i = 0; i < CATEGORIES.length; i++) {
            final int category = i;
            int y = top + i * 24;

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal((page == category ? "> " : "") + CATEGORIES[i]),
                    button -> {
                        page = category;
                        clearAndInit();
                    }
            ).dimensions(left, y, 120, 20).build());
        }

        int contentLeft = left + 130;

        if (page == 0) {
            addToggle(contentLeft, 55, "Zorbix Renderer",
                    FpsBoostClient.CONFIG.rendererEnabled,
                    value -> FpsBoostClient.CONFIG.rendererEnabled = value);

            addToggle(contentLeft, 82, "Smart Chunk Queue",
                    FpsBoostClient.CONFIG.smartChunkQueue,
                    value -> FpsBoostClient.CONFIG.smartChunkQueue = value);

            addToggle(contentLeft, 109, "Entity Culling",
                    FpsBoostClient.CONFIG.entityCulling,
                    value -> FpsBoostClient.CONFIG.entityCulling = value);
        } else if (page == 1) {
            addToggle(contentLeft, 55, "Fast Graphics",
                    FpsBoostClient.CONFIG.graphicsFast,
                    value -> FpsBoostClient.CONFIG.graphicsFast = value);

            addToggle(contentLeft, 82, "Clouds OFF",
                    FpsBoostClient.CONFIG.cloudsOff,
                    value -> FpsBoostClient.CONFIG.cloudsOff = value);

            addToggle(contentLeft, 109, "Ambient Occlusion OFF",
                    FpsBoostClient.CONFIG.ambientOcclusionOff,
                    value -> FpsBoostClient.CONFIG.ambientOcclusionOff = value);

            addToggle(contentLeft, 136, "Entity Shadows OFF",
                    FpsBoostClient.CONFIG.entityShadowsOff,
                    value -> FpsBoostClient.CONFIG.entityShadowsOff = value);
        } else if (page == 2) {
            addToggle(contentLeft, 55, "Minimal Particles",
                    FpsBoostClient.CONFIG.minimalParticles,
                    value -> FpsBoostClient.CONFIG.minimalParticles = value);
        } else if (page == 3) {
            addToggle(contentLeft, 55, "View Bobbing",
                    FpsBoostClient.CONFIG.viewBobbing,
                    value -> FpsBoostClient.CONFIG.viewBobbing = value);
            addToggle(contentLeft, 82, "FOV Effects",
                    FpsBoostClient.CONFIG.fovEffects,
                    value -> FpsBoostClient.CONFIG.fovEffects = value);
        } else if (page == 4) {
            addToggle(contentLeft, 55, "Weather Effects",
                    FpsBoostClient.CONFIG.weatherEffects,
                    value -> FpsBoostClient.CONFIG.weatherEffects = value);
            addToggle(contentLeft, 82, "Fog",
                    FpsBoostClient.CONFIG.fog,
                    value -> FpsBoostClient.CONFIG.fog = value);
        } else if (page == 5) {
            addToggle(contentLeft, 55, "F3 Zorbix Info",
                    FpsBoostClient.CONFIG.performanceHud,
                    value -> FpsBoostClient.CONFIG.performanceHud = value);
        } else {
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("PERFORMANCE"),
                    button -> applyProfile(0)
            ).dimensions(contentLeft, 55, 170, 20).build());

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("BALANCED"),
                    button -> applyProfile(1)
            ).dimensions(contentLeft, 82, 170, 20).build());

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("QUALITY"),
                    button -> applyProfile(2)
            ).dimensions(contentLeft, 109, 170, 20).build());

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("POTATO"),
                    button -> applyProfile(3)
            ).dimensions(contentLeft, 136, 170, 20).build());
        }

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Done"),
                button -> close()
        ).dimensions(this.width / 2 - 100, this.height - 28, 200, 20).build());
    }

    private void addToggle(int x, int y, String name, boolean value, ToggleSetter setter) {
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(name + ": " + (value ? "ON" : "OFF")),
                button -> {
                    boolean next = !valueFrom(button.getMessage().getString());
                    setter.set(next);
                    button.setMessage(Text.literal(name + ": " + (next ? "ON" : "OFF")));
                }
        ).dimensions(x, y, 210, 20).build());
    }

    private static boolean valueFrom(String text) {
        return text.endsWith("ON");
    }

    private void applyProfile(int profile) {
        switch (profile) {
            case 0 -> {
                FpsBoostClient.CONFIG.graphicsFast = true;
                FpsBoostClient.CONFIG.cloudsOff = true;
                FpsBoostClient.CONFIG.ambientOcclusionOff = true;
                FpsBoostClient.CONFIG.entityShadowsOff = true;
                FpsBoostClient.CONFIG.minimalParticles = true;
                FpsBoostClient.CONFIG.entityCulling = true;
            }
            case 1 -> {
                FpsBoostClient.CONFIG.graphicsFast = true;
                FpsBoostClient.CONFIG.cloudsOff = true;
                FpsBoostClient.CONFIG.ambientOcclusionOff = true;
                FpsBoostClient.CONFIG.entityShadowsOff = false;
                FpsBoostClient.CONFIG.minimalParticles = false;
                FpsBoostClient.CONFIG.entityCulling = true;
            }
            case 2 -> {
                FpsBoostClient.CONFIG.graphicsFast = false;
                FpsBoostClient.CONFIG.cloudsOff = false;
                FpsBoostClient.CONFIG.ambientOcclusionOff = false;
                FpsBoostClient.CONFIG.entityShadowsOff = false;
                FpsBoostClient.CONFIG.minimalParticles = false;
                FpsBoostClient.CONFIG.entityCulling = false;
            }
            case 3 -> {
                FpsBoostClient.CONFIG.graphicsFast = true;
                FpsBoostClient.CONFIG.cloudsOff = true;
                FpsBoostClient.CONFIG.ambientOcclusionOff = true;
                FpsBoostClient.CONFIG.entityShadowsOff = true;
                FpsBoostClient.CONFIG.minimalParticles = true;
                FpsBoostClient.CONFIG.entityCulling = true;
            }
        }
        clearAndInit();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                this.title,
                this.width / 2,
                15,
                0xFFFFFF
        );
        context.drawTextWithShadow(
                this.textRenderer,
                Text.literal("Zorbix renderer configuration"),
                this.width / 2 - 20,
                32,
                0xAAAAAA
        );
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (client != null) {
            client.setScreen(parent);
        }
    }

    private interface ToggleSetter {
        void set(boolean value);
    }
}
