package com.zorbix.fpsboost;

import com.zorbix.fpsboost.config.ZorbixConfig;
import com.zorbix.fpsboost.gui.ZorbixOptionsScreen;
import com.zorbix.fpsboost.renderer.ZorbixRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class FpsBoostClient implements ClientModInitializer {
    public static final ZorbixConfig CONFIG = new ZorbixConfig();
    public static final ZorbixRenderer RENDERER = new ZorbixRenderer();
    public static KeyBinding OPTIONS_KEY;

    @Override
    public void onInitializeClient() {
        OPTIONS_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorbix.options",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F8,
                "category.zorbix"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        while (OPTIONS_KEY.wasPressed()) {
            client.setScreen(new ZorbixOptionsScreen(client.currentScreen));
        }

        if (client.options == null || !CONFIG.rendererEnabled) {
            return;
        }

        client.options.getParticles().setValue(
                CONFIG.minimalParticles ? ParticlesMode.MINIMAL : ParticlesMode.ALL
        );
        client.options.getCloudRenderMode().setValue(
                CONFIG.cloudsOff ? CloudRenderMode.OFF : CloudRenderMode.FANCY
        );
        client.options.getGraphicsMode().setValue(
                CONFIG.graphicsFast ? GraphicsMode.FAST : GraphicsMode.FANCY
        );
        client.options.getAo().setValue(!CONFIG.ambientOcclusionOff);
        client.options.getEntityShadows().setValue(!CONFIG.entityShadowsOff);
        client.options.getBobView().setValue(CONFIG.viewBobbing);
        client.options.getFovEffectScale().setValue(CONFIG.fovEffects ? 1.0 : 0.0);

        RENDERER.tick(client);
    }
}
