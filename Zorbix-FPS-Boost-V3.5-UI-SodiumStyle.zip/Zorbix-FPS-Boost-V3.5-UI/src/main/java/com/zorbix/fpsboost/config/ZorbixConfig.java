package com.zorbix.fpsboost.config;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public class ZorbixConfig {
    public boolean rendererEnabled = true;
    public boolean frustumPipeline = true;
    public boolean smartChunkQueue = true;
    public boolean entityCulling = true;
    public boolean performanceHud = true;

    public ParticlesMode particles = ParticlesMode.MINIMAL;
    public CloudRenderMode clouds = CloudRenderMode.OFF;
    public GraphicsMode graphics = GraphicsMode.FAST;
    public boolean ambientOcclusion = false;
    public boolean entityShadows = false;

    // Zorbix UI settings.
    public boolean graphicsFast = true;
    public boolean cloudsOff = true;
    public boolean ambientOcclusionOff = true;
    public boolean entityShadowsOff = true;
    public boolean minimalParticles = true;
    public boolean viewBobbing = true;
    public boolean fovEffects = true;
    public boolean weatherEffects = true;
    public boolean fog = true;
}
