# Zorbix FPS Boost V3.5 Pre-Release — UI Build

Minecraft 1.20.1 Fabric / Java 17.

This build adds the Zorbix settings interface directly to the vanilla Video Settings screen.

Open:
Minecraft Settings -> Video Settings -> Zorbix Settings

The Zorbix interface contains:
- Performance
- Graphics
- Animations
- Camera & FOV
- Environment
- HUD
- Profiles

F8 still opens the quick Zorbix screen.

For stability, the experimental WorldRenderer mixin is disabled in this UI build while the renderer crash is being isolated. No adaptive render-distance or simulation-distance logic is used.

Build:
gradle build --no-daemon

Output:
build/libs/zorbix-fpsboost-3.5.0.jar
